// string
var nombre = "Anabel";
var apellido = 'Vegas';
var email; // undefined
// number
var edad = 52;
var numero = 7.4;
var hexadecimal = 0xf00d;
var binario = 36;
var octal = 2775;
// boolean
var soltero = true;
var trabajador; // undefined
var activo = true; // No se recomienda
// any
var algo = true;
algo = 'Hola';
algo = 546;
var variable; // por defecto el tipo es any
// arrays
var lista = [1, 2, 3, 4, 5, 6];
var lista2 = [1, 2, 3, 4, 5, 6];
var lista3 = [1, 2, 3, 4, 5, 6];
var letras = ['a', 'b', 'c'];
// letras.push(7);    ERROR
// tuplas
var producto = ['Melocotones', 1.50];
var producto2 = ['Melocotones', 1.50];
console.log("Fruta: " + producto2[0]);
console.log("Precio: " + producto2[1]);
// enum
//enum PuntoCardinal{NORTE, SUR, ESTE, OESTE};
var PuntoCardinal;
(function (PuntoCardinal) {
    PuntoCardinal[PuntoCardinal["NORTE"] = 1] = "NORTE";
    PuntoCardinal[PuntoCardinal["SUR"] = 2] = "SUR";
    PuntoCardinal[PuntoCardinal["ESTE"] = 3] = "ESTE";
    PuntoCardinal[PuntoCardinal["OESTE"] = 4] = "OESTE";
})(PuntoCardinal || (PuntoCardinal = {}));
;
var punto = PuntoCardinal.OESTE;
console.log(PuntoCardinal[3]); // ESTE
console.log(PuntoCardinal[punto]);
// null y undefined
// en tsconfig.json    ->   "strictNullChecks": false
var n = undefined;
var texto = null;
// aserciones
var num1 = 5;
var num2 = 6;
//let suma: number = num1 + num2;
var suma = num1 + num2;
console.log("Suma: ".concat(suma));
// void
function saludar() {
    alert("Hola, que tal?");
}
saludar();
function operacion(n1, n2) {
    return n1 + n2;
}
console.log("Resultado: " + operacion(4, 9));
