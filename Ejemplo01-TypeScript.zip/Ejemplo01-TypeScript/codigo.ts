// string
let nombre: string = "Anabel";
let apellido: string = 'Vegas';
let email: string;   // undefined

// number
let edad: number = 52;
let numero: number = 7.4;
let hexadecimal: number = 0xf00d;
let binario: number = 0b100100;
let octal: number = 0o5327;

// boolean
let soltero: boolean = true;
let trabajador: boolean;   // undefined
let activo = true;   // No se recomienda

// any
let algo: any = true;
algo = 'Hola';
algo = 546;
let variable;    // por defecto el tipo es any

// arrays
let lista = [1,2,3,4,5,6];
let lista2: number[] = [1,2,3,4,5,6];
let lista3: Array<number> = [1,2,3,4,5,6];
let letras: string[] = ['a', 'b', 'c'];
// letras.push(7);    ERROR

// tuplas
let producto = ['Melocotones', 1.50];
let producto2: [string, number] = ['Melocotones', 1.50];
console.log("Fruta: " +  producto2[0]);
console.log("Precio: " + producto2[1]);

// enum
//enum PuntoCardinal{NORTE, SUR, ESTE, OESTE};
enum PuntoCardinal{NORTE=1, SUR, ESTE, OESTE};
let punto: PuntoCardinal =  PuntoCardinal.OESTE;
console.log(PuntoCardinal[3]);   // ESTE
console.log(PuntoCardinal[punto]);

// null y undefined
// en tsconfig.json    ->   "strictNullChecks": false
let n: number = undefined;
let texto: string = null;

// aserciones
let num1: unknown = 5;
let num2: unknown = 6;
//let suma: number = num1 + num2;
let suma: number = (<number>num1) + (num2 as number);
console.log(`Suma: ${suma}`);

// void
function saludar(): void{
    alert("Hola, que tal?");
}
saludar();

function operacion(n1: number, n2: number): number{
    return n1 + n2;
}
console.log( "Resultado: " + operacion(4,9));