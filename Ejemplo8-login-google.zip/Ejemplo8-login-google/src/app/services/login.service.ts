import { Observable } from 'rxjs';
import { SocialAuthService, SocialUser, GoogleLoginProvider } from '@abacritt/angularx-social-login';
import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  constructor(private authService: SocialAuthService) { }

  login(): Promise<SocialUser>  {
    return this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
  }

  logout(): Promise<void> {
    return this.authService.signOut();
  }

  comprobarLogado(): Observable<SocialUser> {
    return this.authService.authState;
  }
}
