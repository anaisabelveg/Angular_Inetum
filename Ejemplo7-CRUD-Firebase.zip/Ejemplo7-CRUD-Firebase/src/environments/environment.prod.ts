export const environment = {
  production: true,
  firebaseConfig:{
    apiKey: "AIzaSyAYOHiBK57fzRSvHKpg0ehc4ikZ2kzGoyA",
    authDomain: "hiberus-tardes-ana.firebaseapp.com",
    projectId: "hiberus-tardes-ana",
    storageBucket: "hiberus-tardes-ana.appspot.com",
    messagingSenderId: "850941606639",
    appId: "1:850941606639:web:21a47ca6ba54ffcbac391a"
  }
};
