import { LoginService } from './../../services/login.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  registro: boolean = false;     // true -> registro,   false -> login
  email: string = '';
  password: string = '';
  confirmPassword: string = '';
  logado: boolean = false;

  constructor(private loginService: LoginService) { }

  cerrarSession(){
    this.loginService.logout()
      .then( (datos) => {
        console.log(datos);
        this.logado = false;
      })
      .catch( (error) => {
        console.log(error);
        alert("No se pudo cerrar la session");
      });
  }

  login(){
    this.loginService.login(this.email, this.password)
      .then( (datos) => {
        console.log(datos);
        this.logado = true;
      })
      .catch( (error) => {
        console.log(error);
        alert("Usuario no existe")
      });
  }

  registrar(){
    if (this.password == this.confirmPassword){
      this.loginService.registro(this.email, this.password)
      .then( (datos) => {
        console.log(datos);
        alert("Usuario registrado");
      })
      .catch( (error) => {
        console.log(error);
        alert("No se puedo registrar como usuario");
      });
    } else {
      alert("Por favor comprueba la confirmacion de password");
    }
  }


  ngOnInit(): void {
  }

}
